#!/usr/bin/env python3
"""Pin-checked, isolated, *experimental* Webots R2025a instrumentation.

No GitHub mutation. Run only in a dedicated, clean source worktree at the
R2025a peeled commit. The output is an unreviewed experimental candidate,
not a WebeeBlocks patch or an experimentally validated Webots build.
"""
from pathlib import Path
import hashlib
import subprocess
import sys

PIN = 'c6793d8f7230a311c4bc2a3101d9f1a8bc0aa01b'


def replace_once(s, old, new, path):
    n = s.count(old)
    if n != 1:
        raise RuntimeError(f'{path}: expected 1 unique anchor, found {n}: {old[:65]!r}')
    return s.replace(old, new, 1)


def main():
    if len(sys.argv) != 2:
        raise SystemExit('usage: patch_webots_h6.py /path/to/isolated/webots-source')
    root = Path(sys.argv[1]).resolve()
    sha = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
    if sha != PIN:
        raise SystemExit(f'REFUSED: expected Webots {PIN}, got {sha}')
    dirty = subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain'], text=True).strip()
    if dirty:
        raise SystemExit('REFUSED: Webots source worktree must be clean')
    changes = {}

    def read(path):
        return (root / path).read_text(encoding='utf-8')

    def change(path, old, new):
        s = changes.get(path, read(path))
        changes[path] = replace_once(s, old, new, path)

    header = r'''// H6 isolated probe: ONLY for Webots c6793d8f; not production.
#ifndef ODE_H6_PROBE_H
#define ODE_H6_PROBE_H
#include <ode/ode.h>
#include <cstdint>
struct H6ContactRecord {
  uint64_t magic;
  uint64_t id;
  dBodyID b1;
  dBodyID b2;
  dJointGroupID group;
  double x, y, z, nx, ny, nz, depth, created_time;
  dJointFeedback feedback;
};
static constexpr uint64_t H6_CONTACT_MAGIC = UINT64_C(0x4836434f4e544143);
#endif
'''
    header_path = 'include/ode/ode/h6_probe.h'
    if (root / header_path).exists():
        raise SystemExit('REFUSED: probe header already exists')

    # All H6 state belongs to one experimental Webots process. Contact-record
    # allocations remain stable until process exit; freeing them at joint deletion
    # would make post-solver evidence dangerously reference freed memory.
    context_hpp = 'src/webots/ode/WbOdeContext.hpp'
    change(context_hpp, '  void removeBodyContactJointGroup(dBodyID b);', '''  void removeBodyContactJointGroup(dBodyID b);

  // BEGIN H6 EXPERIMENTAL API; these functions are no-ops without WEBEE_H6_MODE=A/B.
  void h6RegisterContact(dJointID joint, dJointGroupID group, dBodyID b1, dBodyID b2,
                         const dContact *contact, double sim_time);
  void h6ArmReset(dBodyID body);
  void h6BeforeResume(dBodyID body);
  void h6RecordBody(const char *phase) const;
  // END H6 EXPERIMENTAL API
''')

    context_cpp = 'src/webots/ode/WbOdeContext.cpp'
    change(context_cpp, '#include "WbOdeContext.hpp"', r'''#include "WbOdeContext.hpp"
// BEGIN H6 ISOLATED EXPERIMENT
#include <ode/h6_probe.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <vector>
#include <unistd.h>  // readlink(/proc/self/exe) for actual runtime executable

static unsigned long long h6NextJointId = 0;
static unsigned long long h6StepIndex = 0;
static std::vector<std::unique_ptr<H6ContactRecord>> h6Records;
static dBodyID h6ArmedBody = nullptr;
static std::vector<uint64_t> h6BeforeIds;
static const char *h6Mode() {
  const char *mode = std::getenv("WEBEE_H6_MODE");
  return mode && (!std::strcmp(mode, "A") || !std::strcmp(mode, "B")) ? mode : nullptr;
}
static std::vector<uint64_t> h6Ids(dBodyID body) {
  std::vector<uint64_t> ids;
  if (!body)
    return ids;
  const int count = dBodyGetNumJoints(body);
  for (int i = 0; i < count; ++i) {
    dJointID joint = dBodyGetJoint(body, i);
    if (dJointGetType(joint) != dJointTypeContact)
      continue;
    // Compare pointers to known record addresses BEFORE dereferencing:
    // an unrelated plugin may use the ODE joint's userdata for other purposes.
    void *data = dJointGetData(joint);
    for (const auto &record : h6Records) {
      if (record.get() == data) {
        ids.push_back(record->id);
        break;
      }
    }
  }
  std::sort(ids.begin(), ids.end());
  return ids;
}
// Capture the executable and memory map from *inside the actual Webots process*.
// ldd predicts dependencies but /proc/self/maps proves a runtime load.
static void h6CaptureRuntimeImage() {
  char path[4096] = {};
  const ssize_t n = readlink("/proc/self/exe", path, sizeof(path)-1);
  if (n <= 0) {
    std::fprintf(stderr,"H6 INVALID runtime_executable_unavailable\n");
    std::abort();
  }
  path[n] = '\0';
  std::fprintf(stderr, "H6 event=runtime_image exe=%s\n",path);
  FILE *maps = std::fopen("/proc/self/maps", "r");
  if (!maps) {
    std::fprintf(stderr,"H6 INVALID runtime_maps_unavailable\n");
    std::abort();
  }
  char line[8192];
  int evidence = 0;
  while (std::fgets(line,sizeof(line),maps)) {
    if (std::strstr(line,"webots-bin") || std::strstr(line,"libode") || std::strstr(line,"/webots/")) {
      std::fprintf(stderr,"H6 event=runtime_mapping detail=%s",line);
      ++evidence;
    }
  }
  std::fclose(maps);
  if (!evidence) {
    std::fprintf(stderr,"H6 INVALID runtime_no_webots_mapping\n");
    std::abort();
  }
}
// END H6 ISOLATED EXPERIMENT
''')
    # Native registration happens immediately after attachment; assign a
    # monotonically increasing experimental ID, NEVER a recycled ODE pointer.
    changes[context_cpp] += r'''
// BEGIN H6 ISOLATED EXPERIMENT
void WbOdeContext::h6RegisterContact(dJointID joint, dJointGroupID group, dBodyID b1, dBodyID b2,
                                      const dContact *contact, double sim_time) {
  if (!h6Mode())
    return;
  std::unique_ptr<H6ContactRecord> r(new H6ContactRecord{});
  r->magic = H6_CONTACT_MAGIC;
  r->id = ++h6NextJointId;
  r->b1 = b1;
  r->b2 = b2;
  r->group = group;
  r->x = contact->geom.pos[0]; r->y = contact->geom.pos[1]; r->z = contact->geom.pos[2];
  r->nx = contact->geom.normal[0]; r->ny = contact->geom.normal[1]; r->nz = contact->geom.normal[2];
  r->depth = contact->geom.depth;
  // Age is tracked by creation sequence and ordered log events, not wall time.
  r->created_time = sim_time;
  const auto id = static_cast<unsigned long long>(r->id);
  dJointSetData(joint, r.get());
  dJointSetFeedback(joint, &r->feedback);
  h6Records.emplace_back(std::move(r));
  std::fprintf(stderr,
    "H6 event=create id=%llu step=%llu sim_time=%.17g joint=%p group=%p b1=%p b2=%p px=%.17g py=%.17g pz=%.17g "
    "nx=%.17g ny=%.17g nz=%.17g depth=%.17g\n",
    id, h6StepIndex, sim_time, static_cast<void *>(joint), static_cast<void *>(group), static_cast<void *>(b1),
    static_cast<void *>(b2), contact->geom.pos[0], contact->geom.pos[1], contact->geom.pos[2],
    contact->geom.normal[0], contact->geom.normal[1], contact->geom.normal[2], contact->geom.depth);
}

void WbOdeContext::h6RecordBody(const char *phase) const {
  if (!h6Mode() || !h6ArmedBody)
    return;
  if (!std::strcmp(phase, "before_integrate_and_collide"))
    ++h6StepIndex;
  dBodyID b = h6ArmedBody;
  const dReal *pos = dBodyGetPosition(b), *vel = dBodyGetLinearVel(b), *omega = dBodyGetAngularVel(b);
  const dReal *quat = dBodyGetQuaternion(b);
  const dReal *force = dBodyGetForce(b), *torque = dBodyGetTorque(b);
  dMass mass;
  dBodyGetMass(b, &mass);
  const auto ids = h6Ids(b);
  std::fprintf(stderr,
    "H6 event=body step=%llu phase=%s enabled=%d nold_current=%zu pos=%.17g,%.17g,%.17g "
    "v=%.17g,%.17g,%.17g omega=%.17g,%.17g,%.17g "
    "force=%.17g,%.17g,%.17g torque=%.17g,%.17g,%.17g "
    "mass=%.17g I=%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g "
    "quat=%.17g,%.17g,%.17g,%.17g\n",
    h6StepIndex, phase, dBodyIsEnabled(b), ids.size(), pos[0],pos[1],pos[2],
    vel[0],vel[1],vel[2],omega[0],omega[1],omega[2],
    force[0],force[1],force[2],torque[0],torque[1],torque[2],
    mass.mass,mass.I[0],mass.I[1],mass.I[2],mass.I[4],mass.I[5],mass.I[6],
    mass.I[8],mass.I[9],mass.I[10],quat[0],quat[1],quat[2],quat[3]);
}

void WbOdeContext::h6ArmReset(dBodyID body) {
  if (!h6Mode())
    return;
  if (h6ArmedBody)
    std::abort(); // experiment is one-reset only
  h6ArmedBody = body;
  h6CaptureRuntimeImage();
  h6BeforeIds = h6Ids(body);
  for (uint64_t id : h6BeforeIds)
    std::fprintf(stderr,"H6 event=armed_old_joint id=%llu\n", static_cast<unsigned long long>(id));
  std::fprintf(stderr,"H6 event=ode_threads configured=%d\n",mNumberOfThreads);
  if (mNumberOfThreads != 1) {
    std::fprintf(stderr,"H6 INVALID physics_thread_count_mismatch\n");
    std::abort();
  }
  h6RecordBody("at_reset_before_disable");
  std::fprintf(stderr, "H6 event=armed body=%p contacts=%zu mode=%s\n", static_cast<void *>(body), h6BeforeIds.size(), h6Mode());
  if (h6BeforeIds.empty()) {
    std::fprintf(stderr, "H6 INVALID no_native_contact_joint_before_reset\n");
    std::abort();
  }
}

void WbOdeContext::h6BeforeResume(dBodyID body) {
  if (!h6Mode() || body != h6ArmedBody)
    return;
  h6RecordBody("before_resume_and_intervention");
  const auto current = h6Ids(body);
  for (uint64_t id : current) {
    if (!std::binary_search(h6BeforeIds.begin(), h6BeforeIds.end(), id)) {
      std::fprintf(stderr, "H6 INVALID fresh_contact_joint_at_intervention id=%llu\n",
                   static_cast<unsigned long long>(id));
      std::abort(); // critical: would otherwise remove new contacts too
    }
  }
  const auto it1 = mBodyContactJointGroupList1.find(body);
  const auto it2 = mBodyContactJointGroupList2.find(body);
  dJointGroupID groups[2] = {
    it1 != mBodyContactJointGroupList1.end() ? it1.value() : nullptr,
    it2 != mBodyContactJointGroupList2.end() ? it2.value() : nullptr
  };
  std::fprintf(stderr, "H6 event=intervention_boundary step=%llu mode=%s before=%zu currently=%zu "
                       "group0_count=%d group1_count=%d\n", h6StepIndex, h6Mode(),
    h6BeforeIds.size(), current.size(), groups[0] ? dJointGroupGetCount(groups[0]) : 0,
    groups[1] ? dJointGroupGetCount(groups[1]) : 0);
  if (!std::strcmp(h6Mode(), "B")) {
    // Fail closed: a group may not contain even one untracked/fresh joint.
    // Count records by their creation IDs and original owning group.
    for (dJointGroupID g : groups) {
      if (!g) continue;
      int annotated = 0;
      for (const auto &r : h6Records)
        if (r->group == g && std::binary_search(current.begin(),current.end(),r->id))
          ++annotated;
      const int n = dJointGroupGetCount(g);
      if (n != annotated) {
        std::fprintf(stderr,"H6 INVALID untracked_joint_in_target_group group=%p count=%d annotated=%d\n",
                     static_cast<void *>(g), n, annotated);
        std::abort();
      }
    }
    // ALL joints in these per-body groups are old in this *verified* fixture.
    // No other body can own a group keyed by this body in the standard callback.
    for (dJointGroupID group : groups) {
      if (group && dJointGroupGetCount(group)) {
        // Detect group ownership: fail closed if any non-snapshotted contact
        // is attached to the target body (checked above).
        std::fprintf(stderr, "H6 event=intervention_drop step=%llu group=%p count=%d\n",
                     h6StepIndex, static_cast<void *>(group), dJointGroupGetCount(group));
        dJointGroupEmpty(group);
      }
    }
    if (!h6Ids(body).empty()) {
      std::fprintf(stderr,"H6 INVALID intervention_left_attached_contacts\n");
      std::abort();
    }
  }
  h6RecordBody("after_intervention_before_resume");
}
// END H6 ISOLATED EXPERIMENT
'''
    change(context_cpp, '''void WbOdeContext::emptyEnabledBodyContactJointGroups1() {
  // mutex is locked in WbSimulationCluster before calling this function
  QHashIterator<dBodyID, dJointGroupID> it(mBodyContactJointGroupList1);
  while (it.hasNext()) {
    it.next();
    if (dBodyIsEnabled(it.key()))
      dJointGroupEmpty(it.value());''', '''void WbOdeContext::emptyEnabledBodyContactJointGroups1() {
  // mutex is locked in WbSimulationCluster before calling this function
  QHashIterator<dBodyID, dJointGroupID> it(mBodyContactJointGroupList1);
  while (it.hasNext()) {
    it.next();
    if (h6Mode() && dJointGroupGetCount(it.value()))
      std::fprintf(stderr, "H6 event=cleanup buffer=1 group=%p body=%p enabled=%d count=%d\\n",
                   static_cast<void *>(it.value()), static_cast<void *>(it.key()),
                   dBodyIsEnabled(it.key()), dJointGroupGetCount(it.value()));
    if (dBodyIsEnabled(it.key()))
      dJointGroupEmpty(it.value());''')
    change(context_cpp, '''void WbOdeContext::emptyEnabledBodyContactJointGroups2() {
  // mutex is locked in WbSimulationCluster before calling this function
  QHashIterator<dBodyID, dJointGroupID> it(mBodyContactJointGroupList2);
  while (it.hasNext()) {
    it.next();
    if (dBodyIsEnabled(it.key()))
      dJointGroupEmpty(it.value());''', '''void WbOdeContext::emptyEnabledBodyContactJointGroups2() {
  // mutex is locked in WbSimulationCluster before calling this function
  QHashIterator<dBodyID, dJointGroupID> it(mBodyContactJointGroupList2);
  while (it.hasNext()) {
    it.next();
    if (h6Mode() && dJointGroupGetCount(it.value()))
      std::fprintf(stderr, "H6 event=cleanup buffer=2 group=%p body=%p enabled=%d count=%d\\n",
                   static_cast<void *>(it.value()), static_cast<void *>(it.key()),
                   dBodyIsEnabled(it.key()), dJointGroupGetCount(it.value()));
    if (dBodyIsEnabled(it.key()))
      dJointGroupEmpty(it.value());''')

    # The register call runs with the group creation mutex held. One thread is
    # required by the world. No other consumer of contact-joint userdata is used.
    cluster = 'src/webots/engine/WbSimulationCluster.cpp'
    change(cluster, '''    dJointID contactJoint = dJointCreateContact(jointWorld, group, &contact[i]);
    dJointAttach(contactJoint, b1, b2);
    cJointCreationMutex->unlock();''', '''    dJointID contactJoint = dJointCreateContact(jointWorld, group, &contact[i]);
    dJointAttach(contactJoint, b1, b2);
    cl->mContext->h6RegisterContact(contactJoint, group, b1, b2, &contact[i],
                                     WbSimulationState::instance()->time());
    cJointCreationMutex->unlock();''')
    change(cluster, '''  dWorldStepAndSpaceCollide(mContext->space(), this, odeNearCallback, mContext->world(),
                            WbWorld::instance()->basicTimeStep() * 0.001, &dWorldStep, spaceUpdateFunc);''', '''  mContext->h6RecordBody("before_integrate_and_collide");
  dWorldStepAndSpaceCollide(mContext->space(), this, odeNearCallback, mContext->world(),
                            WbWorld::instance()->basicTimeStep() * 0.001, &dWorldStep, spaceUpdateFunc);
  mContext->h6RecordBody("after_integrate_and_collide_before_cleanup");''')
    change(cluster, '''  dImmersionLinkGroupEmpty(immersionLinkGroup());

  WbSolidDevice::clearDirtySensorsList();''', '''  dImmersionLinkGroupEmpty(immersionLinkGroup());
  mContext->h6RecordBody("after_contact_cleanup");

  WbSolidDevice::clearDirtySensorsList();''')

    solid = 'src/webots/nodes/WbSolid.cpp'
    change(solid, '''    resetSingleSolidPhysics();
    if (mSolidMerger)
      mSolidMerger->setBodyArtificiallyDisabled(false);
    mResetPhysicsInStep = false;''', '''    resetSingleSolidPhysics();
    if (mSolidMerger)
      WbOdeContext::instance()->h6BeforeResume(mSolidMerger->body());
    if (mSolidMerger)
      mSolidMerger->setBodyArtificiallyDisabled(false);
    if (mSolidMerger)
      WbOdeContext::instance()->h6RecordBody("after_resume");
    mResetPhysicsInStep = false;''')
    change(solid, '''void WbSolid::pausePhysics(bool resumeAutomatically) {
  if (resumeAutomatically)
    mResetPhysicsInStep = true;''', '''void WbSolid::pausePhysics(bool resumeAutomatically) {
  // The world contains exactly one dynamic body and one RESET. Do not rely
  // on defName() propagating through the Crazyflie EXTERNPROTO wrapper.
  if (resumeAutomatically && mSolidMerger)
    WbOdeContext::instance()->h6ArmReset(mSolidMerger->body());
  if (resumeAutomatically)
    mResetPhysicsInStep = true;''')

    # Log the **effective** velocity of each propeller every pre-physics
    # step, before any conditional return on absent geometry or helix.
    propeller = 'src/webots/nodes/WbPropeller.cpp'
    change(propeller, '''  const bool run = m->runKinematicControl(ms, mPosition);
  if (!run)
    return;''', '''  const bool run = m->runKinematicControl(ms, mPosition);
  if (std::getenv("WEBEE_H6_MODE"))
    std::fprintf(stderr, "H6 event=motor_effective phase=prePhysicsStep name=%s omega=%.17g\\n",
                 m->deviceName().toUtf8().constData(), m->currentVelocity());
  if (!run)
    return;''')
    change(propeller, '''    dBodyAddTorque(b, torqueVector.x(), torqueVector.y(), torqueVector.z());

    updateHelix(absoluteVelocity);''', '''    dBodyAddTorque(b, torqueVector.x(), torqueVector.y(), torqueVector.z());
    if (std::getenv("WEBEE_H6_MODE"))
      std::fprintf(stderr, "H6 event=motor_force phase=prePhysicsStep name=%s thrust=%.17g drag_torque=%.17g "
                           "fx=%.17g fy=%.17g fz=%.17g tx=%.17g ty=%.17g tz=%.17g\\n",
                   m->deviceName().toUtf8().constData(), mCurrentThrust, mCurrentTorque,
                   thrustVector.x(),thrustVector.y(),thrustVector.z(),
                   torqueVector.x(),torqueVector.y(),torqueVector.z());

    updateHelix(absoluteVelocity);''')
    # std::getenv + std::fprintf includes. Add after existing includes, safely.
    change(propeller, '#include "WbPropeller.hpp"', '''#include "WbPropeller.hpp"
// BEGIN H6 ISOLATED EXPERIMENT
#include <cstdio>
#include <cstdlib>
// END H6 ISOLATED EXPERIMENT''')

    # ODE solver-level evidence: only a joint actually selected in an island
    # gets a 'solver_member' and a post-step feedback record. This cannot be
    # inferred from a contact point or a group count alone.
    util = 'src/ode/ode/src/util.cpp'
    change(util, '#include "util.h"', '''#include "util.h"
// BEGIN H6 ISOLATED EXPERIMENT
#include <ode/h6_probe.h>
#include <cstdio>
#include <cstdlib>
// END H6 ISOLATED EXPERIMENT''')
    change(util, '''      stepper (stepperarena,world,bodystart,bcount,jointstart,jcount,stepSize);''', '''      // BEGIN H6: solver membership immediately before the true ODE step.
      if (std::getenv("WEBEE_H6_MODE")) {
        for (unsigned int q=0; q<jcount; ++q) {
          dxJoint *j = jointstart[q];
          if (dJointGetType(j) != dJointTypeContact) continue;
          auto *r = static_cast<H6ContactRecord *>(dJointGetData(j));
          if (!r || r->magic != H6_CONTACT_MAGIC) continue;
          std::fprintf(stderr, "H6 event=solver_member id=%llu body0=%p body1=%p dt=%.17g\\n",
            static_cast<unsigned long long>(r->id), static_cast<void *>(dJointGetBody(j,0)),
            static_cast<void *>(dJointGetBody(j,1)), stepSize);
        }
      }
      stepper (stepperarena,world,bodystart,bcount,jointstart,jcount,stepSize);
      if (std::getenv("WEBEE_H6_MODE")) {
        for (unsigned int q=0; q<jcount; ++q) {
          dxJoint *j = jointstart[q];
          if (dJointGetType(j) != dJointTypeContact) continue;
          auto *r = static_cast<H6ContactRecord *>(dJointGetData(j));
          if (!r || r->magic != H6_CONTACT_MAGIC) continue;
          const dJointFeedback *fb = dJointGetFeedback(j);
          if (!fb) { std::fprintf(stderr,"H6 INVALID no_joint_feedback id=%llu\\n",
                static_cast<unsigned long long>(r->id)); std::abort(); }
          std::fprintf(stderr,
            "H6 event=solver_feedback id=%llu fx1=%.17g fy1=%.17g fz1=%.17g "
            "tx1=%.17g ty1=%.17g tz1=%.17g "
            "fx2=%.17g fy2=%.17g fz2=%.17g tx2=%.17g ty2=%.17g tz2=%.17g\\n",
            static_cast<unsigned long long>(r->id),
            fb->f1[0],fb->f1[1],fb->f1[2],fb->t1[0],fb->t1[1],fb->t1[2],
            fb->f2[0],fb->f2[1],fb->f2[2],fb->t2[0],fb->t2[1],fb->t2[2]);
        }
      }
      // END H6 ISOLATED EXPERIMENT''')

    # Do not write until all anchors matched; never partially patch source.
    for p in changes:
        if not (root/p).is_file():
            raise RuntimeError(f'missing source {p}')
    for p, text in changes.items():
        (root/p).write_text(text, encoding='utf-8')
    (root/header_path).write_text(header, encoding='utf-8')
    print('H6 patches applied in isolated Webots checkout; code is UNCOMPILED/UNTESTED in this environment')
    print('Baseline', sha)
    for p in sorted(list(changes) + [header_path]):
        print('patched', p, hashlib.sha256((root/p).read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
