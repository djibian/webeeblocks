#!/usr/bin/env python3
"""Fail-closed H6 native A/B log inspector.

This script *never* fabricates Webots results. If measurements are absent,
its answer remains UNPROVEN or explicitly INVALID, not a synthetic pass.
"""
import argparse
import json
import math
import os
import re
from pathlib import Path

STEP_S = 0.032
EXPECTED_SHA = 'c6793d8f7230a311c4bc2a3101d9f1a8bc0aa01b'


def invalid(message):
    raise ValueError('INVALID_NATIVE_ACQUISITION: ' + message)


def vec(s):
    x = [float(v) for v in s.split(',')]
    if not all(math.isfinite(v) for v in x):
        invalid('non-finite vector')
    return x


def norm(xs):
    return math.sqrt(sum(x*x for x in xs))


def sub(a,b):
    return [x-y for x,y in zip(a,b)]


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


def mul(A,x):
    return [dot(row,x) for row in A]


def mulmat(A,B):
    return [[dot(row,[B[k][j] for k in range(3)]) for j in range(3)] for row in A]


def angular_momentum_world(d):
    q = vec(d['quat'])
    w,x,y,z = q
    if abs(norm(q)-1)>1e-6:
        invalid('invalid ODE quaternion norm')
    R = [
      [1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
      [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
      [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]
    ]
    I = vec(d['I'])
    if len(I)!=9:
        invalid('ODE inertia tensor incomplete')
    Ib=[I[0:3],I[3:6],I[6:9]]
    Rt=[[R[j][i] for j in range(3)] for i in range(3)]
    Iw=mulmat(mulmat(R,Ib),Rt)
    return mul(Iw,vec(d['omega']))


def read_events(path):
    # Native events have exactly ONE file descriptor; stdout/stderr are combined
    # by run_ab.sh before starting Webots. No across-stream causal inference.
    logfile=path/'run.log'
    if not logfile.is_file():
        invalid(f'missing ordered native log {logfile}')
    lines=logfile.read_text(errors='replace').splitlines()
    if any('H6 INVALID' in line for line in lines):
        invalid('native/controller assertion failure')
    events=[]
    controller=[]
    for line in lines:
        i=line.find('H6 event=')
        if i>=0:
            d=dict(re.findall(r'(\w+)=([^\s]+)',line[i:]))
            if 'event' in d: events.append(d)
        i=line.find('H6_CONTROLLER {')
        if i>=0:
            try: controller.append(json.loads(line[i+len('H6_CONTROLLER '):]))
            except (ValueError, TypeError): invalid('malformed Supervisor record')
    if not any(e['event']=='armed' for e in events):
        invalid('missing native arm marker in ordered output')
    if not any(e['event']=='body' for e in events):
        invalid('missing native body evidence in ordered output')
    if not any(e['event']=='runtime_image' for e in events):
        invalid('runtime loaded image identity not captured')
    return events,controller,lines


def locate(events, event, after=-1, phase=None):
    for i in range(after+1,len(events)):
        d=events[i]
        if d['event']==event and (phase is None or d.get('phase')==phase):
            return i,d
    invalid('missing event '+event+(' phase '+phase if phase else ''))


def parse_branch(path, mode):
    if (path/'process_exit_code.txt').read_text().strip()!='0':
        invalid(f'{mode} Webots process nonzero exit')
    e,ctl,lines=read_events(path)
    image_events = [r for r in e if r['event']=='runtime_image']
    if len(image_events)!=1 or not image_events[0].get('exe'):
        invalid(f'{mode}: missing unique in-process executable identification')
    iarm,arm=locate(e,'armed')
    if arm.get('mode')!=mode or int(arm.get('contacts','0'))<1:
        invalid(f'{mode} invalid arm / no pre-existing contacts')
    ibound,bound=locate(e,'intervention_boundary',after=iarm)
    armed_ids=[int(x['id']) for x in e[:ibound] if x['event']=='armed_old_joint']
    if len(armed_ids)!=int(arm['contacts']) or len(set(armed_ids))!=len(armed_ids):
        invalid('armed joint identity set differs from attached joint count')
    threads=[x for x in e[:ibound] if x['event']=='ode_threads']
    if len(threads)!=1 or threads[0].get('configured')!='1':
        invalid('ODE is not conclusively configured single-threaded')
    iresume,resume=locate(e,'body',after=ibound,phase='after_resume')
    iintegr,integr=locate(e,'body',after=iresume,phase='after_integrate_and_collide_before_cleanup')
    _,pre=locate(e,'body',after=iarm,phase='before_resume_and_intervention')
    if int(pre['enabled'])!=0 or int(resume['enabled'])!=1:
        invalid(f'{mode}: reset disable/enable not observed')
    if any(ee['event']=='intervention_drop' for ee in e[:ibound]):
        invalid('contact intervention before decision boundary')
    if mode=='A' and any(ee['event']=='intervention_drop' for ee in e):
        invalid('A was not passive')
    created_before={int(x['id']):x for x in e[:iarm] if x['event']=='create'}
    if not created_before:
        invalid('no native contact creation recorded before RESET')
    if any(i not in created_before for i in armed_ids):
        invalid('armed joint never appeared in native creation trace')
    # At the arm point, all historic IDs must exist; no new joints may be
    # introduced between arm and intervention, even outside body enumeration.
    if any(x['event']=='create' for x in e[iarm+1:ibound]):
        invalid('new contacts generated between arm and intervention')
    solver=[x for x in e[iresume:iintegr] if x['event']=='solver_member']
    feedback=[x for x in e[iresume:iintegr] if x['event']=='solver_feedback']
    old_solver=[x for x in solver if int(x['id']) in armed_ids]
    if old_solver and int(bound.get('currently','0')) < 1:
        invalid('stale solver joint seen despite no old joint at intervention boundary')
    if mode=='B' and (old_solver or int(bound.get('currently','0'))==0):
        # The latter indicates no identified target of intervention: B no-op.
        invalid('B has stale joints in solver or no joints available at intervention')
    feedback_by_id={int(x['id']):x for x in feedback}
    if len(feedback_by_id)!=len(feedback):
        invalid('duplicate solver feedback id')
    # Across processes, pointer values differ. Geometry, creation order and
    # topology are compared rather than virtual addresses.
    old_geometry=[]
    for id_ in sorted(armed_ids):
        r=created_before[id_]
        old_geometry.append({key: r[key] for key in ('px','py','pz','nx','ny','nz','depth')})
    target=arm['body']
    torque=[0.,0.,0.]
    contact_components=[]
    for joint in old_solver:
        id_=int(joint['id'])
        if id_ not in feedback_by_id:
            invalid('solver included contact joint but its force feedback is missing')
        fb=feedback_by_id[id_]
        if joint['body0']==target:
            t=[float(fb[k]) for k in ('tx1','ty1','tz1')]
        elif joint['body1']==target:
            t=[float(fb[k]) for k in ('tx2','ty2','tz2')]
        else:
            invalid('old joint in solver was not attached to target body')
        if not all(math.isfinite(x) for x in t):
            invalid('non-finite ODE feedback torque')
        torque=[a+b for a,b in zip(torque,t)]
        contact_components.append({'joint_id':id_,'torque_body_world_Nm':t,'impulse_Nms':[q*STEP_S for q in t]})
    L0=angular_momentum_world(resume)
    L1=angular_momentum_world(integr)
    dt_l=sub(L1,L0)
    motors=[x for x in e[:ibound] if x['event']=='motor_effective']
    last_motors={x['name']:float(x['omega']) for x in motors}
    if len(last_motors)!=4:
        invalid(f'{mode}: expected 4 effective motor readings, found {len(last_motors)}')
    if any(abs(v)>1e-10 for v in last_motors.values()):
        invalid(f'{mode}: unexpectedly spinning motor in motor-off fixture')
    if not ctl:
        invalid(f'{mode}: missing Supervisor native state events')
    if not any('H6_CONTROLLER end_of_one_shot_experiment' in line for line in lines):
        invalid(f'{mode}: Supervisor did not finish cleanly')
    samples={x.get('label'):x for x in ctl}
    for key in ['contacts_prepared_by_ode']+[f'after_reset_step_{n}' for n in range(1,7)]:
        if key not in samples:invalid(f'{mode}: missing Supervisor {key}')
    if samples['contacts_prepared_by_ode']['count_contacts']<1:
        invalid('no genuine observed contact before reset')
    if norm(vec(resume['omega']))>1e-8:
        invalid('angular velocity not zero after reset before first resumed integration')
    return {
      'mode':mode,'executed_image':image_events[0]['exe'],
      'old_contacts_created_before_reset':sorted(created_before),
      'old_contacts_armed_at_reset':sorted(armed_ids),
      'old_contacts_geometry':old_geometry,
      'target_body':target,'armed_old_contacts':int(arm['contacts']),
      'at_intervention':bound,'boundary_native':pre,
      'four_motor_effective_omega_before_intervention':last_motors,
      'solver_old_joint_ids':[int(x['id']) for x in old_solver],
      'solver_total_contact_members':len(solver),
      'old_contact_impulses':contact_components,
      'old_contacts_aggregate_torque_Nm':torque,
      'old_contacts_integrated_torque_impulse_Nms':[v*STEP_S for v in torque],
      'angular_velocity_after_resume_rad_s':vec(resume['omega']),
      'angular_velocity_after_next_integration_rad_s':vec(integr['omega']),
      'delta_L_world_Nms':dt_l,
      'intervention_events':[x for x in e if x['event']=='intervention_drop'],
      'controller_after_1_2':{k:samples[k] for k in ['after_reset_step_1','after_reset_step_2']},
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('result_directory',type=Path)
    ap.add_argument('--check-a', action='store_true', help='fail closed before B unless A has stale solver membership')
    args=ap.parse_args()
    root=args.result_directory
    result={'scope':'isolated native Webots experiment; not the historical #671 trajectory',
            'physical_state':'UNVERIFIED unless source/binary provenance & logs are supplied',
            'mechanism_verdict':'UNPROVEN', 'historical_671_verdict':'UNPROVEN',
            'no_production_change':True}
    try:
        A=parse_branch(root/'A','A')
        if args.check_a:
            # In-process image must resolve to exact expected isolated executable.
            envfile=root/'env.txt'
            if not envfile.is_file():
                invalid('missing native environment manifest in A gate')
            envitems=dict(line.split('=',1) for line in envfile.read_text().splitlines() if '=' in line)
            image_expected=os.path.realpath(os.path.join(envitems.get('webots_home',''),'bin/webots-bin'))
            if os.path.realpath(A['executed_image']) != image_expected:
                invalid('wrong executable in A branch')
            # A is measured before B. Never execute B just because A exited 0.
            stale = A['solver_old_joint_ids']
            result.update(branches={'A': A}, should_run_B=bool(stale),
                          decision=('A_OLD_JOINT_IN_SOLVER; B_CONDITION_MET' if stale else
                                    'STOP_NO_OLD_JOINT_IN_SOLVER; B_PROHIBITED'))
            print(json.dumps(result,ensure_ascii=False,indent=2))
            return 0 if stale else 4
        B=parse_branch(root/'B','B')
        result['branches']={'A':A,'B':B}
        envfile=root/'env.txt'
        if not envfile.is_file():
            invalid('missing native environment manifest')
        manifest={}
        for line in envfile.read_text().splitlines():
            if '=' in line:
                key,value=line.split('=',1)
                manifest[key]=value
        home=manifest.get('webots_home')
        if not home:
            invalid('missing Webots home identity')
        expected_image=os.path.realpath(os.path.join(home,'bin/webots-bin'))
        for branch in (A,B):
            if os.path.realpath(branch['executed_image'])!=expected_image:
                invalid('in-process Webots binary differs from expected isolated webots-bin')
        result['runtime_executable_path']=expected_image
        fields=['enabled','nold_current','pos','v','omega','force','torque','mass','I','quat']
        boundary_equal=all(A['boundary_native'].get(k)==B['boundary_native'].get(k) for k in fields)
        motors_equal=A['four_motor_effective_omega_before_intervention']==B['four_motor_effective_omega_before_intervention']
        # Contact identities are monotone per process; their equality between
        # A and B additionally requires matching creation order and groups.
        topology_equal=(A['armed_old_contacts']==B['armed_old_contacts']
                        and A['old_contacts_armed_at_reset']==B['old_contacts_armed_at_reset']
                        and A['at_intervention']['currently']==B['at_intervention']['currently']
                        and A['old_contacts_geometry']==B['old_contacts_geometry'])
        result['observed_preintervention_boundary_equal']=boundary_equal
        result['motor_state_equal']=motors_equal
        result['contact_id_sets_equal']=topology_equal
        result['strict_hidden_state_equality_proven']=False # intentionally never claimed from process restarts
        a=norm(A['angular_velocity_after_next_integration_rad_s'])
        b=norm(B['angular_velocity_after_next_integration_rad_s'])
        result['delta_omega_norm_rad_s']={'A':a,'B':b,'reduction':a-b}
        result['new_torque_evidence']='feedback is contact-joint solver torque, not complete dynamics balance'
        result['causality_decision']='UNPROVEN'
        if not (boundary_equal and motors_equal and topology_equal):
            result['causality_decision']='UNPROVEN: initial measured state mismatch; no controlled A/B'
        elif A['solver_old_joint_ids'] and B['solver_old_joint_ids']:
            result['causality_decision']='UNPROVEN: stale solver contacts remain in B; intervention unsuccessful'
        elif not A['solver_old_joint_ids']:
            result['causality_decision']='REFUTED for THIS fixture: no old joint integrated in A'
            result['mechanism_verdict']='REFUTED'
        elif not B['intervention_events']:
            result['causality_decision']='UNPROVEN: B did not record its one-factor intervention'
        elif abs(a-b)<=max(1e-6,a*1e-4):
            result['causality_decision']='UNPROVEN: old joints integrated but no measurable angular change from removal'
        else:
            result['causality_decision']='CANDIDATE CAUSAL DIFFERENCE: old joint participates A but is absent B; rerun and audit solver feedback, environment, ABI and hidden state before PROVEN'
            result['mechanism_verdict']='UNPROVEN'
            # Intentionally cannot self-certify PROVEN from just one synthetic pair.
    except Exception as exc:
        result['invalid_or_missing_data']=str(exc)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if not result.get('invalid_or_missing_data') else 5

if __name__=='__main__':
    raise SystemExit(main())
