#!/usr/bin/env bash
# Build first: apply patch in a clean, *isolated* Webots R2025a checkout,
# rebuild the Webots binary + bundled ODE, and point WEBOTS_EXECUTABLE there.
# No network access, no GitHub writes, no modification of product source.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${WEBOTS_EXECUTABLE:?point to the rebuilt isolated Webots R2025a binary}"
: "${WEBOTS_HOME:?point to the rebuilt isolated Webots R2025a installation}"
OUT="${1:-${ROOT}/results/$(date -u +%Y%m%dT%H%M%SZ)}"
if [[ -e "$OUT" ]]; then echo "REFUSED: output path already exists: $OUT" >&2; exit 2; fi
mkdir -p "$OUT"
if [[ ! -f "$WEBOTS_HOME/resources/version.txt" ]] ||    [[ "$(tr -d '\r\n' < "$WEBOTS_HOME/resources/version.txt")" != 'R2025a' ]]; then
  echo 'REFUSED: WEBOTS_HOME must resolve to the R2025a installation' >&2; exit 2
fi
if [[ ! -x "$WEBOTS_EXECUTABLE" ]] || [[ ! -x "$WEBOTS_HOME/bin/webots-bin" ]]; then
  echo 'REFUSED: compiled native Webots bin/webots-bin missing' >&2; exit 2
fi
sha256sum "$WEBOTS_EXECUTABLE" "$WEBOTS_HOME/bin/webots-bin" > "$OUT/webots_executable.sha256"
ldd "$WEBOTS_HOME/bin/webots-bin" > "$OUT/webots_bin.ldd.txt" || true
if git -C "$WEBOTS_HOME" rev-parse --is-inside-work-tree 2>/dev/null | grep -qx true; then
 git -C "$WEBOTS_HOME" rev-parse HEAD > "$OUT/webots_sources_git_head.txt"
 git -C "$WEBOTS_HOME" diff --check HEAD > "$OUT/webots_diff_check.log"
 git -C "$WEBOTS_HOME" diff --name-only HEAD > "$OUT/webots_changed_paths.txt"
 if ! diff -u <(sort "$OUT/webots_changed_paths.txt") <(printf '%s\n' \
     src/ode/ode/src/util.cpp src/webots/engine/WbSimulationCluster.cpp \
     src/webots/nodes/WbPropeller.cpp src/webots/nodes/WbSolid.cpp \
     src/webots/ode/WbOdeContext.cpp src/webots/ode/WbOdeContext.hpp | sort) \
     > "$OUT/webots_source_scope_check.log"; then
     echo 'REFUSED: experimental source edits outside six audited paths' >&2; exit 2
 fi
 if [[ ! -f "$WEBOTS_HOME/include/ode/ode/h6_probe.h" ]]; then
     echo 'REFUSED: H6 probe header missing' >&2; exit 2
 fi
 git -C "$WEBOTS_HOME" diff --binary HEAD > "$OUT/experimental_webots.patch"
 if [[ "$(cat "$OUT/webots_sources_git_head.txt")" != 'c6793d8f7230a311c4bc2a3101d9f1a8bc0aa01b' ]]; then
    echo 'REFUSED: unexpected native source revision' >&2; exit 2
 fi
else
  echo 'REFUSED: source checkout must have .git for exact-revision authentication' >&2; exit 2
fi
if ! grep -a -q 'H6 event=armed body=' "$WEBOTS_HOME/bin/webots-bin"; then
  # Conservative: marker may reside in a loaded Webots shared object.
  if ! grep -RalF -q 'H6 event=armed body=' "$WEBOTS_HOME/lib/webots" "$WEBOTS_HOME/lib" 2>/dev/null; then
    echo 'REFUSED: experimental H6 probe absent from built Webots binary/libraries' >&2; exit 2
  fi
fi
find "$WEBOTS_HOME/lib" -type f \( -iname '*ode*.so*' -o -iname '*physics*.so*' \) -print0   | xargs -0 -r sha256sum > "$OUT/physics_library_candidates.sha256"
printf 'webots_executable=%s\nwebots_home=%s\nworld=%s\n' "$WEBOTS_EXECUTABLE" "$WEBOTS_HOME" "$ROOT/worlds/h6_reset_causal.wbt" > "$OUT/env.txt"
# Run A in isolation and determine P2 before authorizing B. Preserve every
# failure; no automatic retry. One merged stdout+stderr stream is canonical.
for MODE in A B; do
  if [[ "$MODE" == 'B' ]] && [[ ! -f "$OUT/A/check-a-approved" ]]; then
    echo 'H6 STOP: no positive A solver-member evidence: B prohibited' >&2
    exit 4
  fi
  mkdir -p "$OUT/$MODE"
  echo "H6 $MODE exactly once, no retries"
  set +e
  WEBEE_H6_MODE="$MODE" timeout --signal=TERM 70s \
    "$WEBOTS_EXECUTABLE" --stdout --stderr --batch --mode=fast --no-rendering \
    "$ROOT/worlds/h6_reset_causal.wbt" \
    >"$OUT/$MODE/run.log" 2>&1
  code=$?
  set -e
  printf '%s\n' "$code" > "$OUT/$MODE/process_exit_code.txt"
  if [[ "$code" != 0 ]]; then
    echo "H6 INVALID: $MODE exited $code; raw logs preserved" >&2; exit "$code"
  fi
  if ! grep -Eq 'H6 event=armed body=[^ ]+ contacts=[1-9][0-9]* mode='"$MODE" "$OUT/$MODE/run.log"; then
    echo "H6 INVALID: $MODE missing armed body/contacts marker" >&2; exit 3
  fi
  if ! grep -q 'H6_CONTROLLER end_of_one_shot_experiment' "$OUT/$MODE/run.log"; then
    echo "H6 INVALID: $MODE Supervisor incomplete" >&2; exit 3
  fi
  if grep -q 'H6 INVALID' "$OUT/$MODE/run.log"; then
    echo "H6 INVALID: native assertion in $MODE" >&2; exit 3
  fi
  if [[ "$MODE" == A ]]; then
    set +e
    python3 "$ROOT/source/analyze_ab.py" "$OUT" --check-a >"$OUT/A/precheck.json"
    precheck_code=$?
    set -e
    if [[ "$precheck_code" != 0 ]]; then
      echo "H6 STOP: A did not qualify P2 (code $precheck_code); B not run" >&2
      sha256sum "$OUT/A/run.log" "$OUT/A/precheck.json" > "$OUT/A/evidence.sha256"
      exit "$precheck_code"
    fi
    touch "$OUT/A/check-a-approved"
  fi
  sha256sum -c "$OUT/webots_executable.sha256" > "$OUT/$MODE/executable_unchanged.log"
  # Actual loaded paths, not just ldd's hypothetical dependency graph.
  sed -n 's/^.*H6 event=runtime_mapping detail=//p' "$OUT/$MODE/run.log" \
    > "$OUT/$MODE/runtime_loaded_mappings.txt"
  awk 'NF >= 6 {print $NF}' "$OUT/$MODE/runtime_loaded_mappings.txt" | sort -u | \
    while IFS= read -r path; do
      if [[ -f "$path" ]]; then sha256sum "$path"; fi
    done > "$OUT/$MODE/runtime_loaded_files.sha256"
done
python3 "$ROOT/source/analyze_ab.py" "$OUT" > "$OUT/verdict.json"
# Analyzer returns nonzero when it cannot validate the native evidence.
sha256sum "$OUT"/{A,B}/run.log "$OUT/verdict.json" > "$OUT/evidence.sha256"
cat "$OUT/verdict.json"
