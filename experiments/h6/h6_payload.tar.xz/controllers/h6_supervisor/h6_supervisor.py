"""One-shot, native Supervisor teleport and resetPhysics causal probe.

No WebeeBlocks runtime, browser, motors or drone hardware. Controller logs
only observations. Refuses experiment if no real contacts were produced by ODE.
"""
import json
import math
import os
import sys
from controller import Supervisor

STEP_MS = 32
RESET_XYZ = [0.0, 0.0, 0.06]
RESET_ROT = [0.0, 0.0, 1.0, 0.0]  # no new floor contacts at target (critical control)
MODE = os.environ.get('WEBEE_H6_MODE', '')
if MODE not in ('A', 'B'):
    raise SystemExit('H6 INVALID: WEBEE_H6_MODE must be A or B')

s = Supervisor()
if int(s.getBasicTimeStep()) != STEP_MS:
    raise RuntimeError('H6 INVALID: physical timestep is not exactly 32 ms')
node = s.getFromDef('H6_DRONE')
if node is None:
    raise RuntimeError('H6 INVALID: missing H6_DRONE node')
xyz_field = node.getField('translation')
rot_field = node.getField('rotation')
if xyz_field is None or rot_field is None:
    raise RuntimeError('H6 INVALID: missing Supervisor pose fields')


def sample(label):
    contacts = node.getContactPoints(includeDescendants=True)
    d = dict(kind='H6_CONTROLLER', label=label, mode=MODE,
             t=s.getTime(), pos=list(node.getPosition()),
             orientation=list(node.getOrientation()),
             vel=list(node.getVelocity()),
             count_contacts=len(contacts),
             contact_points=[list(c.point) for c in contacts])
    for v in d['pos']+d['orientation']+d['vel']:
        if not math.isfinite(v):
            raise RuntimeError('H6 INVALID: non-finite state')
    print("H6_CONTROLLER " + json.dumps(d, sort_keys=True), flush=True)
    return d

print(json.dumps({'kind':'H6_HEADER','mode':MODE,'step_ms':STEP_MS,
                  'world':'h6_reset_causal.wbt','single_thread_required':True,
                  'source':'c6793d8f7230a311c4bc2a3101d9f1a8bc0aa01b'}),flush=True)

# The first physics integration is followed by dSpaceCollide; this is the
# step where ODE must create *real* contacts, rather than merely use a
# deliberately penetrating initial translation field.
if s.step(STEP_MS) == -1:
    raise RuntimeError('H6 INVALID: simulation terminated at contact preparation')
pre = sample('contacts_prepared_by_ode')
if pre['count_contacts'] < 1:
    print('H6 INVALID: no contact point after dSpaceCollide; STOP, no RESET',flush=True)
    sys.exit(2)

# Authentic public Supervisor API; never setVelocity after resetPhysics.
xyz_field.setSFVec3f(RESET_XYZ)
rot_field.setSFRotation(RESET_ROT)
node.resetPhysics()
print('H6_CONTROLLER native Supervisor RESET requested',flush=True)
for i in range(1,7):
    if s.step(STEP_MS) == -1:
        raise RuntimeError('H6 INVALID: simulation stopped before observations')
    sample(f'after_reset_step_{i}')

print('H6_CONTROLLER end_of_one_shot_experiment',flush=True)
s.simulationQuit(0)
