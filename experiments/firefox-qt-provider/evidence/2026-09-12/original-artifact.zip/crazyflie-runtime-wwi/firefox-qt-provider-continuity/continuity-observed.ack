continuity observed before shutdown
