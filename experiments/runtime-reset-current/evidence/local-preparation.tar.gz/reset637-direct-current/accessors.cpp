#include "WbMotor.hpp"
#include "WbPropeller.hpp"
extern "C" double read_current(WbMotor *m){return m->currentVelocity();}
extern "C" double read_thrust(WbPropeller *p){return p->currentThrust();}
extern "C" double read_torque(WbPropeller *p){return p->currentTorque();}
