const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '../..');
const Backend = require(path.join(root, 'plugins/robot_windows/blockly/webeeblocks/wwi_backend.js'));
const [port, mode, directory] = process.argv.slice(2);
function report(event, detail) { fs.appendFileSync(path.join(directory,'events.jsonl'), JSON.stringify({event,detail,wall_ms:Date.now()})+'\n'); }
const socket = new WebSocket('ws://127.0.0.1:'+port+'/');
const backend = new Backend({send:msg=>{report('request',msg);socket.send('robot:Crazyflie WebeeBlocks:'+msg);}}, {simulationReset:true});
socket.onmessage=e=>{for(const line of String(e.data).split(/\r?\n/)){if(!line.startsWith('robot:'))continue;const d=JSON.parse(line.slice(6));if(d.name==='Crazyflie WebeeBlocks'){report('response',d.message);backend.handleMessage(d.message);}}};
socket.onopen=async()=>{try{
 socket.send('robot:Crazyflie WebeeBlocks:init robot window'); await backend.waitUntilReady();
 try { await backend.resetSimulation(); report('RESET_OK',{}); }
 catch(e) { if(e.code!=='RESET_TIMEOUT')throw e; report('RESET_REFUSED',{code:e.code}); }
 report('COMPLETE',{scope:'synthetic motor-state discrimination only'}); socket.close();setTimeout(()=>process.exit(0),30);
}catch(e){report('ERROR',{message:String(e),code:e.code});process.exit(1);}};
setTimeout(()=>{report('WALL_TIMEOUT',{});process.exit(3);},30000).unref();
