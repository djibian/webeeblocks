import hashlib,json,os,subprocess,sys,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('phase',ROOT/'experiments/runtime-reset-phase/instrument.py'); phase=importlib.util.module_from_spec(spec);spec.loader.exec_module(phase)
out=Path(sys.argv[1]).resolve(); assert not out.exists()
c=ROOT/'controllers/crazyflie_runtime_v2/crazyflie_runtime_v2.c'; original=c.read_bytes(); assert original==subprocess.check_output(['git','show','HEAD:controllers/crazyflie_runtime_v2/crazyflie_runtime_v2.c'],cwd=ROOT)
s=phase.instrument(original.decode())
anchor='#define ACTION_TIMEOUT 25.0'
s=s.replace(anchor,anchor+'\n\nstatic void diagnostic_motor_set_velocity(WbDeviceTag tag, double value) {\n  fprintf(stderr, PREFIX " ACTUATOR_COMMAND time=%.9f tag=%d target=%.9f\\n",wb_robot_get_time(),tag,value);\n  wb_motor_set_velocity(tag,value);\n}\n#define wb_motor_set_velocity diagnostic_motor_set_velocity\n')
try:
 c.write_text(s);env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/scratch/fd91538488aa/native/xvfb/usr/lib/x86_64-linux-gnu:'+env.get('LD_LIBRARY_PATH','')
 r=subprocess.run([sys.executable,str(ROOT/'experiments/runtime-reset-contact/run.py'),'--webots-home','/workspace/scratch/fd91538488aa/native/webots','--assets-root','/workspace/scratch/fd91538488aa/native/assets','--xvfb','/workspace/scratch/fd91538488aa/native/xvfb/usr/bin/Xvfb','--mode','baseline','--output',str(out)],cwd=ROOT,env=env)
finally:
 c.write_bytes(original)
 if out.exists():
  (out/'runtime-original.c').write_bytes(original);(out/'runtime-instrumented.c').write_text(s);(out/'acquire-baseline.py').write_bytes(Path(__file__).read_bytes())
  (out/'sha256.json').write_text(json.dumps({str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='sha256.json'},indent=2)+'\n')
sys.exit(r.returncode)
