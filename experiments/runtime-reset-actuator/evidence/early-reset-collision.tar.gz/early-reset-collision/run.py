"""One real TCP collision with early RESET; no fixture, original Runtime logic."""
import hashlib,importlib.util,json,os,re,sys,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
native=module('native',ROOT/'experiments/runtime-reset-contact/run.py')
native.HERE=HERE
original_validate=native.validate_events

def validate(mode,rows,text):
 if any(r['event'] in ('ERROR','RESET_FAILED','TRANSPORT_ERROR','WALL_TIMEOUT') for r in rows):raise ValueError('early-reset experiment refused')
 assert any(r['event']=='FAST_RESET_ACK' for r in rows) and any(r['event']=='FAST_FRESH' for r in rows)
 ids=[re.fullmatch(r'WEBEEBLOCKS_RUNTIME_V2 REQUEST (\d+) RESET',r['detail']) for r in rows if r['event']=='request'];ids=[m[1] for m in ids if m]
 assert len(ids)==len(set(ids))==7
 for ident in ids:assert sum(r['event']=='response' and r['detail']==f'WEBEEBLOCKS_RUNTIME_V2 RESPONSE {ident} OK' for r in rows)==1
 assert 'WEBEEBLOCKS_AUTONOMOUS_COLLISION attempt=7 ' in text and text.count(' TRACE RESET ')==7 and 'RESET_TIMEOUT' not in text
 request=next(i for i,r in enumerate(rows) if r['event']=='request' and r['detail']==f'WEBEEBLOCKS_RUNTIME_V2 REQUEST {ids[-1]} RESET')
 previous=next(i for i,r in enumerate(rows) if r['event']=='response' and r['detail']==f'WEBEEBLOCKS_RUNTIME_V2 RESPONSE {ids[-2]} OK')
 unsafe=[i for i,r in enumerate(rows) if previous<i<request and r['event']=='response' and ' ERR UNSAFE_OR_TIMEOUT' in r['detail']];assert len(unsafe)==1
 assert not any(r['event']=='request' for r in rows[unsafe[0]+1:request])
 return {'scope':'early RESET intervention, no original terminal-outcome-7 claim or historical replay','reset_acks':7,'unsafe_to_reset_no_intervening_request':True}
native.validate_events=validate
out=Path(sys.argv[sys.argv.index('--output')+1]).resolve();c=ROOT/'controllers/crazyflie_runtime_v2/crazyflie_runtime_v2.c';original=c.read_bytes();assert original==subprocess.check_output(['git','show','HEAD:controllers/crazyflie_runtime_v2/crazyflie_runtime_v2.c'],cwd=ROOT)
phase=module('phase',ROOT/'experiments/runtime-reset-phase/instrument.py');s=phase.instrument(original.decode())
anchor='#define ACTION_TIMEOUT 25.0'
s=s.replace(anchor,anchor+'\nstatic void diagnostic_motor_set_velocity(WbDeviceTag tag, double value) { fprintf(stderr, PREFIX " ACTUATOR_COMMAND time=%.9f tag=%d target=%.9f\\n",wb_robot_get_time(),tag,value); wb_motor_set_velocity(tag,value); }\n#define wb_motor_set_velocity diagnostic_motor_set_velocity\n')
try:
 c.write_text(s);result=native.main()
finally:
 c.write_bytes(original)
 if out.exists():
  (out/'runtime-original.c').write_bytes(original);(out/'runtime-instrumented.c').write_text(s)
  for p in HERE.iterdir():
   if p.is_file():(out/p.name).write_bytes(p.read_bytes())
  (out/'sha256.json').write_text(json.dumps({str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='sha256.json'},indent=2)+'\n')
