import hashlib,json,os,subprocess,sys,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('phase',ROOT/'experiments/runtime-reset-phase/instrument.py'); phase=importlib.util.module_from_spec(spec);spec.loader.exec_module(phase)
speed=int(sys.argv[1]); out=Path(sys.argv[2]).resolve(); assert speed in (0,600) and not out.exists()
c=ROOT/'controllers/crazyflie_runtime_v2/crazyflie_runtime_v2.c'; original=c.read_bytes()
def motors(v):return f'wb_motor_set_velocity(m1, -{v}.0); wb_motor_set_velocity(m2, {v}.0); wb_motor_set_velocity(m3, -{v}.0); wb_motor_set_velocity(m4, {v}.0);'
clamp='wb_supervisor_field_set_sf_vec3f(translation_field, initial_translation); wb_supervisor_field_set_sf_rotation(rotation_field, initial_rotation); wb_supervisor_node_reset_physics(self_node);'
s=phase.instrument(original.decode())
ready='  send_text(PREFIX " READY");'
s=s.replace(ready,'  int diagnostic_armed = 1;\n  for (int diagnostic_i=0; diagnostic_i<700; ++diagnostic_i) { '+motors(speed)+clamp+' if (wb_robot_step(step)==-1) return 1; }\n  fprintf(stderr, "ACTUATOR_PREPARED speed='+str(speed)+' time=%.9f\\n",wb_robot_get_time());\n'+ready)
s=s.replace('      if (request.kind == REQUEST_RESET) {','      if (request.kind == REQUEST_RESET) {\n        diagnostic_armed = 0;')
anchor='    previous_time = now;\n    previous_x = x;\n    previous_y = y;\n    previous_z = z;\n  }'
assert s.count(anchor)==1
s=s.replace(anchor,'    if (diagnostic_armed) { '+motors(speed)+clamp+' }\n'+anchor)
s=s.replace('      if (!pose_ready)\n','      fprintf(stderr, "ACTUATOR_TARGET id=%d time=%.9f motors=%.9f,%.9f,%.9f,%.9f\\n",active_id,now,wb_motor_get_velocity(m1),wb_motor_get_velocity(m2),wb_motor_get_velocity(m3),wb_motor_get_velocity(m4));\n      if (!pose_ready)\n')
try:
 c.write_text(s)
 env=os.environ.copy(); env['LD_LIBRARY_PATH']='/workspace/scratch/fd91538488aa/native/xvfb/usr/lib/x86_64-linux-gnu:'+env.get('LD_LIBRARY_PATH','')
 r=subprocess.run([sys.executable,str(Path(__file__).with_name('run-native.py')),'--webots-home','/workspace/scratch/fd91538488aa/native/webots','--assets-root','/workspace/scratch/fd91538488aa/native/assets','--xvfb','/workspace/scratch/fd91538488aa/native/xvfb/usr/bin/Xvfb','--mode','baseline','--output',str(out)],cwd=ROOT,env=env)
finally:
 c.write_bytes(original)
 if out.exists():
  (out/'runtime-original.c').write_bytes(original);(out/'runtime-instrumented.c').write_text(s)
  (out/'actuator-case.json').write_text(json.dumps({'speed':speed,'warmup_steps':700,'scope':'synthetic rotor-state intervention only; no historical attribution'},indent=2)+'\n')
  for p in Path(__file__).parent.iterdir():
   if p.is_file():(out/p.name).write_bytes(p.read_bytes())
  (out/'sha256.json').write_text(json.dumps({str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='sha256.json'},indent=2)+'\n')
sys.exit(r.returncode)
