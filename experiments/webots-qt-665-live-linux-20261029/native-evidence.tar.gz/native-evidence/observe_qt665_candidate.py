import os,sys,time,subprocess,json,importlib.util,traceback
from pathlib import Path
base=Path('/workspace/scratch/5ccc92c234c2');root=base/'webeeblocks';evidence=base/'native-qt665';out=evidence/'candidate-attested';home=evidence/'root/usr/local/webots'
env=dict(os.environ,LD_LIBRARY_PATH=str(evidence/'deps/usr/lib/x86_64-linux-gnu'))
cmd=['python',str(root/'experiments/runtime-reset-contact/run.py'),'--webots-home',str(home),'--assets-root',str(base/'upstream-webots'),'--mode','baseline','--output',str(out),'--xvfb',str(evidence/'deps/usr/bin/Xvfb')]
with (evidence/'candidate-attested-driver.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 attested=False;limit=time.monotonic()+90
 while p.poll() is None and time.monotonic()<limit:
  ready=out/'controller-0.log'
  if ready.exists() and 'WEBEEBLOCKS_RUNTIME_V2 READY' in ready.read_text():
   errors=[]
   for d in Path('/proc').iterdir():
    if not d.name.isdigit():continue
    try:
     if (d/'exe').resolve(strict=True)!=(home/'bin/webots-bin').resolve():continue
     for name in ['maps','stat','status','cmdline']:(out/('live-'+name+'.txt')).write_bytes((d/name).read_bytes())
     result=subprocess.run(['python',str(base/'qt701/experiments/webots-qt-665/attest_running_consumer.py'),'--runtime-home',str(home),'--pid',d.name,'--manifest',str(out/'process-attestation.json')],capture_output=True,text=True)
     (out/'attester.log').write_text(result.stdout+result.stderr);print('ATTESTER',result.returncode,result.stdout,result.stderr,flush=True)
     attested=True;break
    except OSError as exc:errors.append(str(exc))
   if not attested:(out/'attester-refusals.json').write_text(json.dumps(errors));print('NO READABLE LIVE PID',flush=True)
   break
  time.sleep(.2)
 if not attested:print('No positive live attestation yet',flush=True)
 try:code=p.wait(timeout=370)
 except subprocess.TimeoutExpired:p.terminate();code=p.wait(timeout=15)
 print('BASELINE_EXIT',code,flush=True)
 if (out/'process-attestation.json').exists(): print((out/'process-attestation.json').read_text(),flush=True)
