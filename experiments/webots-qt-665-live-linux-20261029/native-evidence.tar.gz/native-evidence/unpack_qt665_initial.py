import urllib.request,json,hashlib,concurrent.futures,tarfile,pathlib
base='https://ghcr.io'; repo='djibian/webeeblocks-qt665-r2025a'; dest=pathlib.Path('/workspace/scratch/5ccc92c234c2/native-qt665'); manifest=json.load(open('/tmp/qt665-oci-manifest.json'))
token=json.load(urllib.request.urlopen(base+'/token?service=ghcr.io&scope=repository:'+repo+':pull',timeout=30))['token']
def fetch(item):
 p=dest/item['digest'].split(':')[1]
 req=urllib.request.Request(base+'/v2/'+repo+'/blobs/'+item['digest'],headers={'Authorization':'Bearer '+token})
 h=hashlib.sha256();size=0
 with urllib.request.urlopen(req,timeout=90) as r, p.open('wb') as f:
  while chunk:=r.read(1024*1024): f.write(chunk);h.update(chunk);size+=len(chunk)
 assert size==item['size'] and 'sha256:'+h.hexdigest()==item['digest']
 print('VERIFIED',item['digest'],size,flush=True);return p
cfg=fetch(manifest['config']);(dest/'config.json').write_bytes(cfg.read_bytes())
items=list({i['digest']:i for i in manifest['layers']}.values())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 paths=dict(zip([i['digest'] for i in items],pool.map(fetch,items)))
root=dest/'root';root.mkdir(exist_ok=True)
for item in manifest['layers']:
 with tarfile.open(paths[item['digest']],'r:gz') as tf:
  members=[m for m in tf if m.name.lstrip('./').startswith('usr/local/webots/')]
  tf.extractall(root,members=members,filter='tar')
 print('EXTRACTED',item['digest'],len(members),flush=True)
print('DONE',flush=True)
