set -eu
export WEBOTS_HOME=/usr/local/webots LIBGL_ALWAYS_SOFTWARE=true
export WEBOTS_DISABLE_SAVE_SCREEN_PERSPECTIVE_ON_CLOSE=true
timeout -k 5s 90s xvfb-run -a webots --stdout --stderr --batch --no-rendering --mode=fast /workspace/worlds/ci_reset_contract.wbt
