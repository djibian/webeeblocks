set -eu
test "$(cat /usr/local/webots/resources/version.txt)" = R2025a
g++ -std=c++17 -O2 -I/usr/local/webots/include/controller/c -I/workspace/controllers/crazyflie_square  /workspace/experiments/runtime-reset-contract/fixture.cpp  /workspace/controllers/crazyflie_runtime_v2/activity_scene.cpp  /workspace/controllers/crazyflie_square/pid_controller.c  -L/usr/local/webots/lib/controller -Wl,-rpath,/usr/local/webots/lib/controller -lController -lm  -o /workspace/controllers/reset_contract/reset_contract
sha256sum /usr/local/webots/bin/webots-bin /workspace/controllers/reset_contract/reset_contract
