import os,sys,subprocess,socket,time
from pathlib import Path
base=Path('/workspace/scratch/69c2f40bf7e6');root=base/'webeeblocks'
for k in list(os.environ):
 if k.lower().endswith('_proxy'):os.environ.pop(k)
os.environ.update(WEBOTS_HOME=str(base/'native-support/webots'),DISPLAY='127.0.0.1:125',USER='root',LD_LIBRARY_PATH=str(base/'native-support/root/usr/lib/x86_64-linux-gnu')+':'+str(base/'native-support/webots/lib/webots'))
os.chdir(root);sys.path.insert(0,str(root))
from tools.ci import run_grand_prix_u_prototype as runner
runner.OUT=base/sys.argv[1]; runner.OUT.mkdir(exist_ok=False)
with socket.socket() as s: s.bind(('127.0.0.1',0)); xp=s.getsockname()[1]
display=xp-6000
os.environ['DISPLAY']='127.0.0.1:'+str(display)
log=(runner.OUT/'xvfb.log').open('w')
xvfb=subprocess.Popen([str(base/'native-support/root/usr/bin/Xvfb'),':'+str(display),'-ac','-nolisten','unix','-nolisten','local','-listen','tcp','-screen','0','1280x1024x24'],stdout=log,stderr=subprocess.STDOUT)
for i in range(100):
 try:
  with socket.create_connection(('127.0.0.1',xp),timeout=.1):break
 except OSError:time.sleep(.05)
else:raise RuntimeError('Xvfb not ready')
try:
 if sys.argv[2]=='all':
  import json
  results=[]
  cases=[(s,'witness') for s in (0,1,3,4,14,15,17)]+[(4,'short'),(4,'timeout'),(0,'timeout-gate'),(1,'wrong-landing'),(0,'low-outside'),(0,'collision'),(0,'reverse'),(0,'unavailable'),(0,'reset')]
  for i,(seed,mode) in enumerate(cases,1):
   results.append(runner.trial(Path(os.environ['WEBOTS_HOME']),seed,mode=mode,tcp=True,sequence_index=i))
   (runner.OUT/'campaign.json').write_text(json.dumps(results,indent=2)+'\n')
 else:runner.trial(Path(os.environ['WEBOTS_HOME']),int(sys.argv[2]),mode=sys.argv[3] if len(sys.argv)>3 else 'witness',tcp=True)
finally:xvfb.terminate();xvfb.wait();log.close()
