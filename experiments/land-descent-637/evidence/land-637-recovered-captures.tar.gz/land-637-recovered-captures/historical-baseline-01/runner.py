import argparse, hashlib, json, os, re, shutil, socket, subprocess, time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--home',type=Path,required=True);p.add_argument('--xvfb',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--variant',choices=['baseline','ramp'],required=True);p.add_argument('--step',type=int,default=32);p.add_argument('--height',default='0.5');p.add_argument('--historical',action='store_true');a=p.parse_args()
 out=a.out.resolve();out.mkdir(parents=True,exist_ok=False);home=a.home.resolve()
 source=(ROOT/'controllers/crazyflie_runtime_v2/crazyflie_runtime_v2.c').read_text()
 if a.variant=='ramp':
  source=source.replace('    } else if (command == CMD_LAND) {\n      desired.altitude = origin_z;', '    } else if (command == CMD_LAND) {\n      desired.altitude = fmax(origin_z, land_start_z - 0.15 * (now - action_start));')
  source=source.replace('  double action_start = 0.0;','  double action_start = 0.0;\n  double land_start_z = 0.0;')
  source=source.replace('        command = CMD_LAND;', '        land_start_z = z;\n        command = CMD_LAND;')
 source=source.replace('const int step = (int)wb_robot_get_basic_time_step();','const int step = 32;')
 source=source.replace('wb_robot_wwi_receive_text()', 'land_receive()').replace('wb_robot_wwi_send_text(text)', 'land_send(text)').replace('wb_robot_step(step)','land_step(step)')
 source='#include <webots/robot.h>\nint land_step(int);\nconst char *land_receive(void);\nvoid land_send(const char*);\n'+source
 (out/'runner.py').write_bytes(Path(__file__).read_bytes());
 (out/'protocol.json').write_text(json.dumps(vars(a),default=str,indent=2));
 (out/'runtime.c').write_text(source);shutil.copy(HERE/'driver.c',out/'driver.c')
 env={**{k:v for k,v in os.environ.items() if not k.lower().endswith('_proxy')},'WEBOTS_HOME':str(home),'LAND_HEIGHT':a.height,'LIBGL_ALWAYS_SOFTWARE':'true','LP_NUM_THREADS':'1','WEBOTS_DISABLE_SAVE_SCREEN_PERSPECTIVE_ON_CLOSE':'true'}
 if a.historical:env['LAND_HISTORICAL']='1'
 env['LD_LIBRARY_PATH']=str(home/'lib/controller')+':'+str(home/'lib/webots')+':'+env.get('LD_LIBRARY_PATH','')
 command=['gcc','-std=c11','-I'+str(home/'include/controller/c'),'-I'+str(ROOT/'controllers/crazyflie_runtime_v2'),'-I'+str(ROOT/'controllers/crazyflie_square'),str(out/'runtime.c'),str(out/'driver.c'),str(ROOT/'controllers/crazyflie_square/pid_controller.c'),'-L'+str(home/'lib/controller'),'-lController','-lm','-o',str(out/'probe')]
 with (out/'build.log').open('w') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 proto=ROOT/'worlds/protos/QualificationCrazyflieR2025a.proto'
 world=f'''#VRML_SIM R2025a utf8
EXTERNPROTO "{proto}"
WorldInfo {{ basicTimeStep {a.step} randomSeed 1 optimalThreadCount 1 }}
Viewpoint {{ position 0 -1 1 orientation 1 0 0 0.8 }}
Solid {{ boundingObject Plane {{ size 4 4 }} }}
QualificationCrazyflieR2025a {{ name "land-body" controller "<extern>" window "<none>" supervisor TRUE
 extensionSlot [ LED {{ name "color_led" }} DistanceSensor {{ name "range_up" rotation 0 1 0 -1.57079632679 lookupTable [0 0 0,2 2000 0] }} ] }}
'''
 (out/'world.wbt').write_text(world)
 dp=port();env['DISPLAY']='127.0.0.1:'+str(dp-6000)
 with (out/'xvfb.log').open('w') as xl:
  xv=subprocess.Popen([a.xvfb,':'+str(dp-6000),'-ac','-nolisten','unix','-nolisten','local','-listen','tcp','-screen','0','1280x1024x24'],env=env,stdout=xl,stderr=subprocess.STDOUT)
  try:
   limit=time.monotonic()+10
   while True:
    try:
     with socket.create_connection(('127.0.0.1',dp),timeout=.2):break
    except OSError:
     if time.monotonic()>limit:raise RuntimeError('Xvfb not ready')
     time.sleep(.1)
   wp=port()
   with (out/'webots.log').open('w') as wl:
    web=subprocess.Popen([str(home/'webots'),'--batch','--minimize','--no-rendering','--mode=fast','--stdout','--stderr','--port='+str(wp),str(out/'world.wbt')],env=env,stdout=wl,stderr=subprocess.STDOUT)
    try:
     limit=time.monotonic()+45
     while 'Waiting for local or remote connection' not in (out/'webots.log').read_text():
      if web.poll() is not None or time.monotonic()>limit:raise RuntimeError('Webots not ready')
      time.sleep(.1)
     with (out/'controller.log').open('w') as cl:
      c=subprocess.run([str(home/'webots-controller'),'--protocol=tcp','--ip-address=127.0.0.1','--port='+str(wp),'--robot-name=land-body',str(out/'probe')],env=env,stdout=cl,stderr=subprocess.STDOUT,timeout=90)
     result=web.wait(timeout=15)
     (out/'exit.json').write_text(json.dumps({'webots':result,'controller':c.returncode}))
    finally:
     if web.poll() is None:web.terminate();web.wait(timeout=10)
  finally:xv.terminate();xv.wait(timeout=10)
 (out/'manifest.json').write_text(json.dumps({str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in out.rglob('*') if f.is_file()},indent=2))
 print('captured',out)
if __name__=='__main__':main()
