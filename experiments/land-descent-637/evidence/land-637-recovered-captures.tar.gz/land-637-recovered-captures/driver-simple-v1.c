#include <webots/robot.h>
#include <webots/supervisor.h>
#include <webots/inertial_unit.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
static int ready=0, index_=0, pending=0, failed=0;
static double done=-1;
static const char *commands[]={"RESET", "TAKEOFF 0.5", "MOVE forward 0.25", "LAND"};
int webeeblocks_activity_scene_ready(void){return 1;}
int webeeblocks_select_activity_scene(const char *s){return 0;}
const char *land_receive(void){
 static char msg[150];
 if(!ready || pending || index_>=4) return NULL;
 const char *cmd=commands[index_];
 if(index_==1 && getenv("LAND_HEIGHT")) {snprintf(msg,sizeof msg,"WEBEEBLOCKS_RUNTIME_V2 REQUEST %d TAKEOFF %s",index_+1,getenv("LAND_HEIGHT"));}
 else snprintf(msg,sizeof msg,"WEBEEBLOCKS_RUNTIME_V2 REQUEST %d %s",index_+1,cmd);
 printf("LAND_EXPERIMENT_REQUEST t=%.9f %s\n",wb_robot_get_time(),msg);fflush(stdout);
 pending=1;return msg;
}
void land_send(const char *s){
 if(strstr(s," READY")){ready=1;return;}
 int id=0;char status[50];
 if(sscanf(s,"WEBEEBLOCKS_RUNTIME_V2 RESPONSE %d %49s",&id,status)==2 && id==index_+1){
  if(strcmp(status,"OK")){failed=1;done=wb_robot_get_time();}
  else {index_++;if(index_==4)done=wb_robot_get_time();}
  pending=0;
 }
}
int land_step(int ms){
 int rc=wb_robot_step(ms); if(rc==-1)return rc;
 double t=wb_robot_get_time();
 if(ready){
  WbNodeRef self=wb_supervisor_node_get_self();
  const double *p=wb_supervisor_node_get_position(self);double pos[3]={p[0],p[1],p[2]};
  const double *v=wb_supervisor_node_get_velocity(self);double vel[6];memcpy(vel,v,sizeof vel);
  const double *o=wb_supervisor_node_get_orientation(self);double rot[9];memcpy(rot,o,sizeof rot);
  int nc;WbContactPoint *cp=wb_supervisor_node_get_contact_points(self,1,&nc);
  printf("LAND_OBS t=%.9f stage=%d pos=%.12g,%.12g,%.12g vel=%.12g,%.12g,%.12g,%.12g,%.12g,%.12g pitch=%.12g contacts=%d",t,index_,pos[0],pos[1],pos[2],vel[0],vel[1],vel[2],vel[3],vel[4],vel[5],atan2(rot[2],rot[8]),nc);
  for(int i=0;i<nc&&i<6;i++)printf(" cp%d=%.12g,%.12g,%.12g",i,cp[i].point[0],cp[i].point[1],cp[i].point[2]);
  puts("");fflush(stdout);
 }
 if((done>=0 && t-done>=3) || t>=45){
  printf("LAND_EXPERIMENT_END completed=%d failed=%d t=%.9f\n",index_==4,failed,t);fflush(stdout);
  wb_supervisor_simulation_quit(failed || index_!=4);return -1;
 }
 return rc;
}
