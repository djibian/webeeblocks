import os, subprocess,sys
from pathlib import Path
base=Path('/workspace/scratch/6877c1bdb9d8')
for step in [32,8]:
 for height in ['0.2','0.35','0.5','0.8','1.0','1.5']:
  n=f'hold-{step}-{height}';out=base/n
  with (base/(n+'.log')).open('w') as log:
   r=subprocess.run([sys.executable,'experiments/land-descent-637/run.py','--home','/workspace/scratch/b69e910503d8/native-support/webots','--xvfb','/workspace/scratch/b69e910503d8/native-support/xserver/usr/bin/Xvfb','--out',str(out),'--variant','ramp-hold','--step',str(step),'--height',height],stdout=log,stderr=subprocess.STDOUT)
  print(n,r.returncode,flush=True)
